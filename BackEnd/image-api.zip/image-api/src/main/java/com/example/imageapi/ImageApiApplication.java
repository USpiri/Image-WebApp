package com.example.imageapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImageApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImageApiApplication.class, args);
	}

}
